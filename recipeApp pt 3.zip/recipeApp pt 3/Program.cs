﻿using System;

// Ingredient class to store the details of an ingredient
public class Ingredient
{
    // Name of the ingredient
    public string Name { get; set; }
    // Quantity of the ingredient
    public double Quantity { get; set; }
    // Unit of measurement for the ingredient
    public string Unit { get; set; }
    // Number of calories
    public double Calories { get; set; }
    // Food group of the ingredient
    public string FoodGroup { get; set; }

    // Constructor to initialize an ingredient
    public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
    {
        Name = name;
        Quantity = quantity;
        Unit = unit;
        Calories = calories;
        FoodGroup = foodGroup;
    }

    // Method to scale the quantity of the ingredient
    public void Scale(double factor)
    {
        Quantity *= factor;
        Calories *= factor;
    }

    // Method to reset the quantity of the ingredient
    public void Reset(double originalQuantity, double originalCalories)
    {
        Quantity = originalQuantity;
        Calories = originalCalories;
    }

    // Override ToString method to display the ingredient details
    public override string ToString()
    {
        return $"{Quantity} {Unit} of {Name} ({Calories} calories, {FoodGroup})";
    }
}
