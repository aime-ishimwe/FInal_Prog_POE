﻿using System.Windows;

namespace RecipeApp
{
    public partial class NewIngredientWindow : Window
    {
        public Ingredient Ingredient { get; private set; }

        public NewIngredientWindow(int ingredientNumber)
        {
            InitializeComponent();
            Title = $"Enter Ingredient {ingredientNumber}";
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            string name = IngredientNameTextBox.Text;
            double quantity = double.Parse(QuantityTextBox.Text);
            string unit = UnitTextBox.Text;
            double calories = double.Parse(CaloriesTextBox.Text);
            string foodGroup = FoodGroupTextBox.Text;

            Ingredient = new Ingredient(name, quantity, unit, calories, foodGroup);
            DialogResult = true;
        }
    }
}
