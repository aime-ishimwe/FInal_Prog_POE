﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
            RecipesListView.ItemsSource = recipes;
        }

        private void EnterNewRecipe_Click(object sender, RoutedEventArgs e)
        {
            var newRecipeWindow = new NewRecipeWindow();
            if (newRecipeWindow.ShowDialog() == true)
            {
                recipes.Add(newRecipeWindow.Recipe);
                RecipesListView.Items.Refresh();
            }
        }

        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipe = (Recipe)RecipesListView.SelectedItem;
            if (selectedRecipe != null)
            {
                var displayRecipeWindow = new DisplayRecipeWindow(selectedRecipe);
                displayRecipeWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a recipe to display.");
            }
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipe = (Recipe)RecipesListView.SelectedItem;
            if (selectedRecipe != null)
            {
                var scaleRecipeWindow = new ScaleRecipeWindow(selectedRecipe);
                if (scaleRecipeWindow.ShowDialog() == true)
                {
                    RecipesListView.Items.Refresh();
                }
            }
            else
            {
                MessageBox.Show("Please select a recipe to scale.");
            }
        }

        private void ResetRecipe_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipe = (Recipe)RecipesListView.SelectedItem;
            if (selectedRecipe != null)
            {
                selectedRecipe.Reset();
                RecipesListView.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Please select a recipe to reset.");
            }
        }

        private void ClearRecipes_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear();
            RecipesListView.Items.Refresh();
        }

        private void ListRecipes_Click(object sender, RoutedEventArgs e)
        {
            var sortedRecipes = recipes.OrderBy(r => r.Name).ToList();
            RecipesListView.ItemsSource = sortedRecipes;
            RecipesListView.Items.Refresh();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
