﻿using System.Windows;

namespace RecipeApp
{
    public partial class NewRecipeWindow : Window
    {
        public Recipe Recipe { get; private set; }

        public NewRecipeWindow()
        {
            InitializeComponent();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            string name = RecipeNameTextBox.Text;
            int numIngredients = int.Parse(NumIngredientsTextBox.Text);
            int numSteps = int.Parse(NumStepsTextBox.Text);

            Recipe = new Recipe(name, numIngredients, numSteps);

            for (int i = 0; i < numIngredients; i++)
            {
                var ingredientWindow = new NewIngredientWindow(i + 1);
                if (ingredientWindow.ShowDialog() == true)
                {
                    Recipe.Ingredients[i] = ingredientWindow.Ingredient;
                }
            }

            for (int i = 0; i < numSteps; i++)
            {
                var stepWindow = new NewStepWindow(i + 1);
                if (stepWindow.ShowDialog() == true)
                {
                    Recipe.Steps[i] = stepWindow.Step;
                }
            }

            Recipe.SaveOriginalQuantitiesAndCalories();
            DialogResult = true;
        }
    }
}
