﻿using System.Windows;

namespace RecipeApp
{
    public partial class NewStepWindow : Window
    {
        public string Step { get; private set; }

        public NewStepWindow(int stepNumber)
        {
            InitializeComponent();
            Title = $"Enter Step {stepNumber}";
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            Step = StepTextBox.Text;
            DialogResult = true;
        }
    }
}
