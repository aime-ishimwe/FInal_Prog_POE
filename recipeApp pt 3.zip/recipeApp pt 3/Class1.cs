﻿using System;
using System.Collections.Generic;

namespace RecipeApp
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public Recipe(string name, int numIngredients, int numSteps)
        {
            Name = name;
            Ingredients = new List<Ingredient>(new Ingredient[numIngredients]);
            Steps = new List<string>(new string[numSteps]);
        }

        public void SaveOriginalQuantitiesAndCalories()
        {
            // Logic to save original quantities and calories
        }

        public void Scale(double factor)
        {
            // Logic to scale the recipe
        }

        public void Reset()
        {
            // Logic to reset the recipe
        }

        public void Display()
        {
            // Logic to display the recipe
        }

        public override string ToString()
        {
            // Logic to return the recipe as a string
            return Name;
        }
    }
}
