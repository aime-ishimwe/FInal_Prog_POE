﻿using System;
using System.Windows;

namespace RecipeApp
{
    public partial class ScaleRecipeWindow : Window
    {
        private Recipe recipe;

        public ScaleRecipeWindow(Recipe recipe)
        {
            InitializeComponent();
            this.recipe = recipe;
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(ScaleFactorTextBox.Text, out double factor))
            {
                recipe.Scale(factor);
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }
    }
}
