﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
    internal class Program
    {
        static List<Recipe> recipes = new List<Recipe>();

        // Commenting out the Main method to avoid conflict with the WPF entry point
        // static void Main(string[] args)
        // {
        //     // Your console application logic here
        // }
    }
}

